Hunter Cleary
625001547

How to Run:
Predicate "path(A,B,P)." will return the shortest path P between two
nodes on a graph given the starting node A and ending node B.

Resources:
http://www.learnprolognow.org/lpnpage.php?pageid=online
https://www.swi-prolog.org/pldoc/man?section=opsummary
https://stackoverflow.com/questions/3965054/prolog-find-minimum-in-a-list
https://rlgomes.github.io/work/prolog/2012/05/22/19.00-prolog-and-graphs.html
https://www.cpp.edu/~jrfisher/www/prolog_tutorial/2_15.html
https://stackoverflow.com/questions/21161624/define-graph-in-prolog-edge-and-path-finding-if-there-is-a-path-between-two-ve


A statement of the Aggie Code of Honor:
An Aggie does not lie, cheat or steal or tolerate those who do.

