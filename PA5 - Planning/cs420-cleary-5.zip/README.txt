Hunter Cleary
625001547

Description to Run:
-The submission was run using the online web planner tool provied. 
-Choose the file "domain.pddl"as the domain. 
-Choose one of the "problem#discs" as the problem file for varying numbers of disc counts to solve for.

Resources:
https://web-planner.herokuapp.com/
https://www.ida.liu.se/~TDDC17/info/labs/planning/writing.html
https://homepages.inf.ed.ac.uk/mfourman/tools/propplan/pddl.pdf
http://www.cs.toronto.edu/~sheila/2542/w19/introtopddl2.pdf


Aggie Honor Code:
"An Aggie does not lie, cheat, or steal, or tolerate those who do."

