Hunter Cleary
625001547

Autograder gave 23/25 on my end. Was unable to improve the consistent food 
heuristic past the 2/4 rating in my available time. 