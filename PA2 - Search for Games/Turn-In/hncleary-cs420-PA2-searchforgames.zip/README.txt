Hunter Cleary
625001547

Autograder gave 25/25 on my end.